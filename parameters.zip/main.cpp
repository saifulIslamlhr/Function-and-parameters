#include <iostream>
using namespace std;

int saif(int a, int b);
void saifprints();

int main() {
 
    saif(15, 99);
    saifprints();

    return 0;

}

int saif(int a, int b)
{

    return b - a;

}

void saifprints() {
 
    cout << "The sum is " << saif(15, 99) << endl;

}